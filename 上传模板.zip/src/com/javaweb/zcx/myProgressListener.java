//�ϴ���java3
package com.javaweb.zcx;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

//import lc.progress.vo.fileUploadStatus;

import org.apache.commons.fileupload.ProgressListener;

public class myProgressListener implements ProgressListener {
	private HttpSession session;

	public myProgressListener(HttpServletRequest req) {
		session=req.getSession();
		fileUploadStatus status = new fileUploadStatus();
		session.setAttribute("status", status);
	}

	/* pBytesRead  ��ĿǰΪֹ��ȡ�ļ��ı�����
	 * pContentLength �ļ��ܴ�С
	 * pItems Ŀǰ���ڶ�ȡ�ڼ����ļ�
	 */
	public void update(long pBytesRead, long pContentLength, int pItems) {
		// TODO Auto-generated method stub
		fileUploadStatus status = (fileUploadStatus) session.getAttribute("status");
		status.setPBytesRead(pBytesRead);
		status.setPContentLength(pContentLength);
		status.setPItems(pItems);
	}

}
