package f1;

import java.io.File;
import java.io.IOException;

public class IO {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO �Զ����ɵķ������
h.cj("d:/1.txt");

 
h.xwj("d:/1.txt","you");
 

h.tssc(h.dwj("d:/1.txt"));


	}
}
