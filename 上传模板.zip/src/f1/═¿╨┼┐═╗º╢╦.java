package f1;

import java.io.DataInputStream;  
import java.io.DataOutputStream;  
import java.io.IOException;  
import java.io.InputStream;  
import java.io.OutputStream;  
import java.net.Socket;  
import java.net.UnknownHostException;  

public class ͨ�ſͻ��� {

	 public static void main(String[] args) {  
	        try {  
	            Socket socket = new Socket("127.0.0.1", 8888);  
	            // ��������˷�������  
	            OutputStream os =  socket.getOutputStream();  
	            DataOutputStream bos = new DataOutputStream(os);  
	            bos.writeUTF("Connect");  
	            bos.flush();  

	            // ���շ�����������  
	            InputStream is = socket.getInputStream();  
	            DataInputStream dis = new DataInputStream(is);  
	            System.out.println(dis.readUTF());  
	        } catch (UnknownHostException e) {  
	            e.printStackTrace();  
	        } catch (IOException e) {  
	            e.printStackTrace();  
	        }  
	 }}