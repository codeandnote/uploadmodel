package f1;


/****************************************
 * ���ǿؼ� ���Ե���
 * ��ʽ:new ������("����");
 * 
 ***************************************/

import java.awt.*;


import javax.swing.*;


public class kj extends JFrame{
		
	
	






		public void CreateJFrame(String title){
		JFrame jf = new JFrame(title);
		Container container = jf.getContentPane();
		//JLabel jl = new JLabel("����");
		//jl.setHorizontalAlignment(SwingConstants.CENTER);
		//container.add(jl);
		container.setBackground(Color.white);
		jf.setVisible(true);
		jf.setSize(200,150);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
		}

		
		
		public  static void ������������(String title){
			new kj().CreateJFrame(title);
		}
	 
		public  static void cjqdck(String title){
			new kj().CreateJFrame(title);
		}
		
		public  static void qdck_bt(String title){
			JFrame jf = new JFrame(title);
			Container container = jf.getContentPane();
			JLabel jl = new JLabel("����");
			jl.setHorizontalAlignment(SwingConstants.CENTER);
			container.add(jl);
		}
		
		
		
		
		
		
		
		
		
		public static void main(String args[]){
			
			new kj().CreateJFrame("hah");
			
		}
	}