package f1;

import java.io.DataInputStream;  
import java.io.DataOutputStream;  
import java.io.IOException;  
import java.io.InputStream;  
import java.io.OutputStream;  
import java.net.ServerSocket;  
import java.net.Socket; 

public class ͨ�ŷ���� {

	public static void main(String[] args) {  
        try {  
            ServerSocket serverSocket = new ServerSocket(8888);  
            Socket socket = serverSocket.accept();  
            // ��ȡ�ͻ�������  
            InputStream info = socket.getInputStream();  
            DataInputStream dis = new DataInputStream(info);  
            System.out.println(dis.readUTF());  

            // ��ͻ����������  
            OutputStream os = socket.getOutputStream();  
            DataOutputStream dos = new DataOutputStream(os);  
            dos.writeUTF("Hello!");  
            dos.flush();  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
    }  
}  
