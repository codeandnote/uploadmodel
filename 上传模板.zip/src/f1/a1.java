package f1;

public class a1 {

	/**
	 * @param args
	 */
	static int b=0;
	static int c=0;
	static int d=1;
	int e=0;
	static String aa="";
	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
for (int a=1;a<=7;a++){
	for(b=1;b<=4;b++)
	{
		;
		//System.out.println("d="+d);
		//System.out.println((b+1)%4);
		if(a+b>=5 && a+b<=8)
			
		{aa=aa+"*";}
		else
		{aa=aa+" ";}
		
	}
	System.out.println(aa);
	aa="";
	d=0;
}
	}

}
