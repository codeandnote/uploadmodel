package f1;

public interface V77 {

}
